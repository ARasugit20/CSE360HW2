package passwordEvaluationTestbed;

/***
 * <p> Title: PasswordEvaluationTestingAutomation Class. </p>
 * 
 * <p> Description: A Java demonstration for semi-automated tests </p>
 * 
 * <p> Copyright: Lynn Robert Carter ©️ 2022 </p>
 * 
 * @author Lynn Robert Carter
 * 
 * @version 1.00	2022-02-25 A set of semi-automated test cases
 * @version 2.00	2024-09-22 Updated for use at ASU
 * 
 */
public class PasswordEvaluationTestingAutomation {
	
	static int numPassed = 0; // Counter of the number of passed tests
	static int numFailed = 0; // Counter of the number of failed tests

	/*
	 * This mainline displays a header to the console, performs a sequence of
	 * test cases, and then displays a footer with a summary of the results
	 */
	public static void main(String[] args) {
		/***** Test cases semi-automation report header *****/
		System.out.println("____________________________________");
		System.out.println("\nTesting Automation");

		/***** Start of the test cases *****/
		
		// Positive test: Valid password
		performTestCase(1, "Cb!15678", true);
		
		// Negative test: Invalid password, too short, missing lowercase and digit
		performTestCase(2, "B!", false);
		
		// Negative test: Empty password
		performTestCase(3, "", false);
		
		// Negative test: Missing special character
		performTestCase(4, "Bb17834", false);
		
		// Negative test: Missing uppercase letter
		performTestCase(5, "bb!12345", false);
		
		// Positive test: Another valid password
		performTestCase(6, "Aa@12892982", true);
		
		/***** End of the test cases *****/
		
		/***** Test cases semi-automation report footer *****/
		System.out.println("__________________________________________________________________________");
		System.out.println();
		System.out.println("Number of tests passed: " + numPassed);
		System.out.println("Number of tests failed: " + numFailed);
	}
	
	/*
	 * This method sets up the input value for the test from the input parameters,
	 * displays test execution information, invokes precisely the same recognizer
	 * that the interactive JavaFX mainline uses, interprets the returned value,
	 * and displays the interpreted result.
	 */
	private static void performTestCase(int testCase, String inputText, boolean expectedPass) {
		/***** Display an individual test case header *****/
		System.out.println("__________________________________________________________________________\n\nTest case: " + testCase);
		System.out.println("Input: \"" + inputText + "\"");
		System.out.println("____________");
		System.out.println("\nFinite state machine execution trace:");
		
		/***** Call the recognizer to process the input *****/
		String resultText = PasswordEvaluator.evaluatePassword(inputText);
		
		/***** Interpret the result and display that interpreted information *****/
		System.out.println();
		
		if (!resultText.isEmpty()) {
			// If the test case expected the password to be valid, but it is invalid
			if (expectedPass) {
				System.out.println("**Failure** The password <" + inputText + "> is invalid.\n" +
						"But it was supposed to be valid, so this is a failure!\n");
				System.out.println("Error message: " + resultText);
				numFailed++;
			} else {
				System.out.println("**Success** The password <" + inputText + "> is invalid.\n" +
						"But it was supposed to be invalid, so this is a pass!\n");
				System.out.println("Error message: " + resultText);
				numPassed++;
			}
		} else {
			// If the test case expected the password to be valid, and it is valid
			if (expectedPass) {
				System.out.println("**Success** The password <" + inputText + "> is valid, so this is a pass!");
				numPassed++;
			} else {
				System.out.println("**Failure** The password <" + inputText + "> was judged as valid\n" +
						"But it was supposed to be invalid, so this is a failure!");
				numFailed++;
			}
		}
		displayEvaluation();
	}
	
	private static void displayEvaluation() {
		if (PasswordEvaluator.foundUpperCase)
			System.out.println("At least one upper case letter - Satisfied");
		else
			System.out.println("At least one upper case letter - Not Satisfied");

		if (PasswordEvaluator.foundLowerCase)
			System.out.println("At least one lower case letter - Satisfied");
		else
			System.out.println("At least one lower case letter - Not Satisfied");
	
		if (PasswordEvaluator.foundNumericDigit)
			System.out.println("At least one digit - Satisfied");
		else
			System.out.println("At least one digit - Not Satisfied");

		if (PasswordEvaluator.foundSpecialChar)
			System.out.println("At least one special character - Satisfied");
		else
			System.out.println("At least one special character - Not Satisfied");

		if (PasswordEvaluator.foundLongEnough)
			System.out.println("At least 8 characters - Satisfied");
		else
			System.out.println("At least 8 characters - Not Satisfied");
	}
}