package application;

import java.time.LocalDateTime;

public class Question {
    private int id;
    private String title;
    private String description;
    private String tags;
    private boolean isResolved;
    private String askedByUser;  
    private LocalDateTime timestamp;

    public Question(int id, String title, String description, String tags, String askedByUser) {
        if (title == null || title.trim().isEmpty()) {
            throw new IllegalArgumentException("Title cannot be empty.");
        }
        if (description == null || description.trim().isEmpty()) {
            throw new IllegalArgumentException("Description cannot be empty.");
        }
        
        this.id = id;
        this.title = title;
        this.description = description;
        this.tags = tags;
        this.askedByUser = askedByUser;
        this.isResolved = false;
        this.timestamp = LocalDateTime.now();
    }

    // Getters
    public int getId() { return id; }
    public String getTitle() { return title; }
    public String getDescription() { return description; }
    public String getTags() { return tags; }
    public String getAskedByUser() { return askedByUser; }
    public boolean isResolved() { return isResolved; }
    public LocalDateTime getTimestamp() { return timestamp; }

    // Setters
    public void setTitle(String title) { this.title = title; }
    public void setDescription(String description) { this.description = description; }
    public void setTags(String tags) { this.tags = tags; }
    public void setAskedByUser(String askedByUser) { this.askedByUser = askedByUser; }

    // Mark the question as resolved
    public void markAsResolved() { this.isResolved = true; }
}
