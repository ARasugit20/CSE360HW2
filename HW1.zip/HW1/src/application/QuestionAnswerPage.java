package application;

import databasePart1.QuestionsDatabaseHelper;
import databasePart1.AnswersDatabaseHelper;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;
import java.sql.SQLException;
import java.util.List;

public class QuestionAnswerPage {
    private final QuestionsDatabaseHelper questionsDB;
    private final AnswersDatabaseHelper answersDB;

    public QuestionAnswerPage(QuestionsDatabaseHelper questionsDB, AnswersDatabaseHelper answersDB) {
        this.questionsDB = questionsDB;
        this.answersDB = answersDB;
    }

    public void show(Stage primaryStage) {
        VBox layout = new VBox(10);
        layout.setStyle("-fx-padding: 20; -fx-alignment: center;");

        Label pageTitle = new Label("Questions & Answers");
        pageTitle.setStyle("-fx-font-size: 18px; -fx-font-weight: bold;");
        

        ListView<String> questionList = new ListView<>();
        Button loadQuestionsButton = new Button("Load Questions");
        Button addQuestionButton = new Button("Add Question");
        Button editQuestionButton = new Button("Edit Question");
        Button deleteQuestionButton = new Button("Delete Question");
        
        questionList.setOnMouseClicked(e -> {
            String selected = questionList.getSelectionModel().getSelectedItem();
            if (selected != null) {
                System.out.println("Selected Question: " + selected);
            }
        });

        ListView<String> answerList = new ListView<>();
        Button loadAnswersButton = new Button("Load Answers");
        Button addAnswerButton = new Button("Add Answer");
        Button editAnswerButton = new Button("Edit Answer");
        
        loadQuestionsButton.setOnAction(e -> loadQuestions(questionList));
        addQuestionButton.setOnAction(e -> addQuestion(questionList));
        editQuestionButton.setOnAction(e -> editQuestion(questionList));
        deleteQuestionButton.setOnAction(e -> deleteQuestion(questionList, answerList));

        loadAnswersButton.setOnAction(e -> loadAnswers(answerList));
        addAnswerButton.setOnAction(e -> addAnswer(answerList, questionList));
        editAnswerButton.setOnAction(e -> editAnswer(answerList));

        layout.getChildren().addAll(pageTitle, loadQuestionsButton, addQuestionButton, editQuestionButton, deleteQuestionButton, questionList,
                                    loadAnswersButton, addAnswerButton, editAnswerButton, answerList);
        primaryStage.setScene(new Scene(layout, 800, 600));
        primaryStage.setTitle("Questions & Answers");
    }

    private void loadQuestions(ListView<String> questionList) {
        questionList.getItems().clear();
        try {
            List<String> questions = questionsDB.getAllQuestions();
            questionList.getItems().addAll(questions.isEmpty() ? List.of("No questions available.") : questions);

            //  Ensure selection is enabled
            questionList.getSelectionModel().setSelectionMode(SelectionMode.SINGLE);
        } catch (SQLException ex) {
            ex.printStackTrace();
            questionList.getItems().add("Error loading questions.");
        }
    }


    private void addQuestion(ListView<String> questionList) {
        TextInputDialog dialog = new TextInputDialog();
        dialog.setTitle("Add Question");
        dialog.setHeaderText("Enter question title:");
        dialog.showAndWait().ifPresent(title -> {
            try {
                questionsDB.addQuestion(title, "Sample description", "tag1,tag2", "user");
                loadQuestions(questionList);
            } catch (SQLException e) {
                e.printStackTrace();
            }
        });
    }

    private void markQuestionAsResolved(ListView<String> questionList) {
        String selected = questionList.getSelectionModel().getSelectedItem();
        if (selected != null) {
            int id = Integer.parseInt(selected.split(": ")[0]);
            try {
                questionsDB.markQuestionAsResolved(id);
                loadQuestions(questionList);
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
    }

    private void markAnswerAsAccepted(ListView<String> answerList) {
        String selected = answerList.getSelectionModel().getSelectedItem();
        if (selected != null) {
            int id = Integer.parseInt(selected.split(": ")[0]);
            try {
                answersDB.markAnswerAsAccepted(id);
                loadAnswers(answerList);
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
    }

    private void editQuestion(ListView<String> questionList) {
        String selected = questionList.getSelectionModel().getSelectedItem();

        if (selected != null && selected.contains(": ")) {
            String[] parts = selected.split(": ", 2);
            int questionId = Integer.parseInt(parts[0]); // Extract ID
            String oldTitle = parts[1]; // Extract old title

            TextInputDialog dialog = new TextInputDialog(oldTitle);
            dialog.setTitle("Edit Question");
            dialog.setHeaderText("Edit question title:");

            dialog.showAndWait().ifPresent(newTitle -> {
                try {
                    questionsDB.updateQuestionTitle(questionId, newTitle); // Update DB

                   
                    showAlert("Success", "Question edited successfully!");

                    //  refreshing the question list
                    loadQuestions(questionList);

                    // reselecting the updated question (prevents selection freeze)
                    questionList.getSelectionModel().clearSelection();
                    questionList.getSelectionModel().select(questionId - 1); // Adjust for 0-based index

                } catch (SQLException e) {
                    e.printStackTrace();
                    showAlert("Error", "Failed to edit question.");
                }
            });
        } else {
            showAlert("Warning", "Please select a valid question to edit.");
        }
    }

    


    private void editAnswer(ListView<String> answerList) {
        String selected = answerList.getSelectionModel().getSelectedItem();

        if (selected != null && selected.matches("^\\d+ \\(Q\\d+\\): .*")) {
            String[] parts = selected.split(": ", 2);
            int answerId = Integer.parseInt(parts[0].split(" ")[0]); // Extract Answer ID
            String oldText = parts[1]; // Extract old answer

            TextInputDialog dialog = new TextInputDialog(oldText);
            dialog.setTitle("Edit Answer");
            dialog.setHeaderText("Edit answer text:");

            dialog.showAndWait().ifPresent(newText -> {
                try {
                    answersDB.updateAnswer(answerId, newText); // Update answer in DB

                    //  Showing confirmation message
                    showAlert("Success", "Answer edited successfully!");

                    // reloading answers list after editing
                    loadAnswers(answerList);

                } catch (SQLException e) {
                    e.printStackTrace();
                    showAlert("Error", "Failed to edit answer.");
                }
            });
        } else {
            showAlert("Warning", "Please select a valid answer to edit.");
        }
    }

    



    private void showAlert(String title, String message) {
        Alert alert = new Alert(Alert.AlertType.ERROR);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }





    private void deleteQuestion(ListView<String> questionList, ListView<String> answerList) {
        String selected = questionList.getSelectionModel().getSelectedItem();
        if (selected != null && selected.contains(": ")) {
            int id = Integer.parseInt(selected.split(": ")[0]);

            Alert confirmation = new Alert(Alert.AlertType.CONFIRMATION, 
                "Are you sure you want to delete this question and its answers?", ButtonType.YES, ButtonType.NO);
            
            confirmation.showAndWait().ifPresent(response -> {
                if (response == ButtonType.YES) {
                    try {
                        questionsDB.deleteQuestion(id);
                        loadQuestions(questionList); // Refresh questions list
                        loadAnswers(answerList); // Ensure answers list is cleared too
                    } catch (SQLException e) {
                        e.printStackTrace();
                    }
                }
            });
        }
    }


    private void loadAnswers(ListView<String> answerList) {
        answerList.getItems().clear();
        try {
            List<String> answers = answersDB.getAllAnswers();
            answerList.getItems().addAll(answers.isEmpty() ? List.of("No answers available.") : answers);
        } catch (SQLException ex) {
            ex.printStackTrace();
            answerList.getItems().add("Error loading answers.");
        }
    }
    private void addAnswer(ListView<String> answerList, ListView<String> questionList) {
        String selectedQuestion = questionList.getSelectionModel().getSelectedItem();

        if (selectedQuestion != null) {
            int questionId = Integer.parseInt(selectedQuestion.split(": ")[0]); // Extract Question ID

            TextInputDialog dialog = new TextInputDialog();
            dialog.setTitle("Add Answer");
            dialog.setHeaderText("Enter answer text:");

            dialog.showAndWait().ifPresent(answerText -> {
                try {
                    answersDB.addAnswer(questionId, answerText, "user");
                    loadAnswers(answerList); // Refresh answers list after adding
                } catch (SQLException e) {
                    e.printStackTrace();
                    showAlert("Error", "Failed to add answer.");
                }
            });
        } else {
            showAlert("Warning", "Please select a question before adding an answer.");
        }
    }

    private void deleteAnswer(ListView<String> answerList) {
        String selected = answerList.getSelectionModel().getSelectedItem();
        if (selected != null && selected.contains(": ")) {
            int id = Integer.parseInt(selected.split(": ")[0]);

            Alert confirmation = new Alert(Alert.AlertType.CONFIRMATION, 
                "Are you sure you want to delete this answer?", ButtonType.YES, ButtonType.NO);
            
            confirmation.showAndWait().ifPresent(response -> {
                if (response == ButtonType.YES) {
                    try {
                        answersDB.deleteAnswer(id);
                        loadAnswers(answerList); // Refresh answer list after deletion
                    } catch (SQLException e) {
                        e.printStackTrace();
                    }
                }
            });
        }
    }

    



}
