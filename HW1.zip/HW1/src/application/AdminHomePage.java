package application;

import java.sql.SQLException;
import java.util.ArrayList;

import databasePart1.DatabaseHelper;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;



/**
 * AdminPage class represents the user interface for the admin user.
 * This page displays a simple welcome message for the admin.
 */

//Added DatabaseHelper
public class AdminHomePage {
	

    private final DatabaseHelper databaseHelper;
    // DatabaseHelper to handle database operations.
    public AdminHomePage(DatabaseHelper databaseHelper) {
        this.databaseHelper = databaseHelper;
    }

	/**
     * Displays the admin page in the provided primary stage.
     * @param primaryStage The primary stage where the scene will be displayed.
     */
    public void show(Stage primaryStage, User user) {
    	VBox layout = new VBox();
    	
	    layout.setStyle("-fx-alignment: center; -fx-padding: 20;");
	    
	    // label to display the welcome message for the admin
	    Label adminLabel = new Label("Hello, Admin!");
	    adminLabel.setStyle("-fx-font-size: 16px; -fx-font-weight: bold;");
	    
	    //Button for Invitation Page
	    Button inviteButton = new Button("Invite");
        inviteButton.setOnAction(a -> {
            new InvitationPage().show(databaseHelper, primaryStage);
        });
	    
        //Button for logout
	    Button Logout = new Button("Logout");
	    Logout.setOnAction(a -> {
	    	new UserLoginPage(databaseHelper).show(primaryStage);
	    });
	    
	    Button listAllButton = new Button("List All Users");
	    listAllButton.setOnAction(a -> {
	    	try {
	    	databaseHelper.listAllUsers();
	    	} catch (SQLException e) {
	        e.printStackTrace();
	    }
	    });
	    Button switchRoles = new Button("Switch Roles");
	    switchRoles.setOnAction(a -> {
	        ArrayList<String> userRoles = databaseHelper.getUserRoleList(user.getUserName());

	        if (userRoles.size() == 1) {
	            // ✅ Directly navigate if user has only one role
	            if ("admin".equals(userRoles.get(0))) {
	                new AdminHomePage(databaseHelper).show(primaryStage, user);
	            } else {
	                new UserHomePage(databaseHelper).show(primaryStage, user);
	            }
	        } else {
	            // ✅ Show role selection if user has multiple roles
	            showRoleSelection(primaryStage, user, userRoles);
	        }
	    });

	    
	    //Button to be able to add or remove user roles and also remove users
	    Button addUserRoleButton = new Button("Add or Remove User Role and or User");
	    addUserRoleButton.setOnAction(a -> {
	    	new AddRemoveUserRole(databaseHelper).show(primaryStage, user );
        });
	    
	    //Adds buttons to layout
  	    layout.getChildren().addAll(adminLabel,inviteButton, addUserRoleButton, switchRoles, listAllButton, Logout);
	    Scene adminScene = new Scene(layout, 800, 400);

	    // Set the scene to primary stage
	    primaryStage.setScene(adminScene);
	    primaryStage.setTitle("Admin Page");
    }

    private void showRoleSelection(Stage primaryStage, User user, ArrayList<String> roles) {
        Stage dialog = new Stage();
        dialog.setTitle("Select Role");

        Label instructionLabel = new Label("You have multiple roles. Choose one:");

        ComboBox<String> roleSelection = new ComboBox<>();
        roleSelection.getItems().addAll(roles);
        roleSelection.setValue(roles.get(0)); // Default to first role

        Button continueButton = new Button("Continue");
        continueButton.setOnAction(e -> {
            String selectedRole = roleSelection.getValue();
            dialog.close();

            if ("admin".equals(selectedRole)) {
                new AdminHomePage(databaseHelper).show(primaryStage, user);
            } else {
                new UserHomePage(databaseHelper).show(primaryStage, user);
            }
        });

        VBox dialogLayout = new VBox(10);
        dialogLayout.setStyle("-fx-padding: 20;");
        dialogLayout.getChildren().addAll(instructionLabel, roleSelection, continueButton);

        dialog.setScene(new Scene(dialogLayout, 400, 200));
        dialog.show();
    }

}