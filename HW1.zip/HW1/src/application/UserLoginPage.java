package application;

import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

import java.sql.SQLException;

import databasePart1.*;

/**
 * The UserLoginPage class provides a login interface for users to access their accounts.
 * It validates the user's credentials and navigates to the appropriate page upon successful login.
 */
public class UserLoginPage {
	
    private final DatabaseHelper databaseHelper;

    public UserLoginPage(DatabaseHelper databaseHelper) {
        this.databaseHelper = databaseHelper;
    }

    public void show(Stage primaryStage) {
    	// Input field for the user's userName, password
        TextField userNameField = new TextField();
        userNameField.setPromptText("Enter userName");
        userNameField.setMaxWidth(250);

        PasswordField passwordField = new PasswordField();
        passwordField.setPromptText("Enter Password");
        passwordField.setMaxWidth(250);
        
        // Label to display error messages
        Label errorLabel = new Label();
        errorLabel.setStyle("-fx-text-fill: red; -fx-font-size: 12px;");

        //Login button
        Button loginButton = new Button("Login");
        
        // Forgot Password button
        Button forgotPasswordButton = new Button("Forgot Password?");
        forgotPasswordButton.setStyle("-fx-text-fill: blue; -fx-underline: true;");

        
        loginButton.setOnAction(a -> {
        	// Retrieve user inputs
            String userName = userNameField.getText();
            String password = passwordField.getText();
            try {
            	User user=new User(userName, password, "");
            	WelcomeLoginPage welcomeLoginPage = new WelcomeLoginPage(databaseHelper);
            	
            	// Retrieve the user's role from the database using userName
            	String role = databaseHelper.getUserRole(userName);
            	
            	if(role!=null) {
            		user.setRole(role);
            		if(databaseHelper.login(user)) {
            			welcomeLoginPage.show(primaryStage,user);
            		}
            		else {
            			// Display an error if the login fails
                        errorLabel.setText("Error logging in");
            		}
            	}
            	else {
            		// Display an error if the account does not exist
                    errorLabel.setText("user account doesn't exists");
            	}
            	
            } catch (SQLException e) {
                System.err.println("Database error: " + e.getMessage());
                e.printStackTrace();
            } 
        });
     // Forgot Password button event handler
        forgotPasswordButton.setOnAction(event -> {
            showForgotPasswordDialog(primaryStage);
        });

        VBox layout = new VBox(10);
        layout.setStyle("-fx-padding: 20; -fx-alignment: center;");
        layout.getChildren().addAll(userNameField, passwordField, loginButton, forgotPasswordButton, errorLabel);

        primaryStage.setScene(new Scene(layout, 800, 400));
        primaryStage.setTitle("User Login");
        primaryStage.show();
    }

    	private void showForgotPasswordDialog(Stage primaryStage) {
        Stage dialog = new Stage();
        dialog.setTitle("Forgot Password");

        // Create UI components for the dialog
        Label instructionLabel = new Label("Enter your username to reset your password:");
        TextField usernameField = new TextField();
        usernameField.setPromptText("Username");

        Label feedbackLabel = new Label();
        feedbackLabel.setStyle("-fx-text-fill: red;");

        Button resetPasswordButton = new Button("Reset Password");
        resetPasswordButton.setOnAction(e -> {
            String username = usernameField.getText().trim();
            if (username.isEmpty()) {
                feedbackLabel.setText("Please enter a valid username.");
                return;
            }

            // Check if the user exists and reset the password
            if (databaseHelper.doesUserExist(username)) {
                try {
                    String newPassword = resetPassword(username);
                    feedbackLabel.setStyle("-fx-text-fill: green;");
                    feedbackLabel.setText("Password reset successful. New password: " + newPassword);
                } catch (SQLException ex) {
                    feedbackLabel.setText("Error resetting password. Please try again.");
                    ex.printStackTrace();
                }
            } else {
                feedbackLabel.setText("Username not found.");
            }
        });

        VBox dialogLayout = new VBox(10);
        dialogLayout.setStyle("-fx-padding: 20;");
        dialogLayout.getChildren().addAll(instructionLabel, usernameField, resetPasswordButton, feedbackLabel);

        dialog.setScene(new Scene(dialogLayout, 400, 200));
        dialog.show();
    }

    private String resetPassword(String username) throws SQLException {
        // Generate a new temporary password
        String tempPassword = "temp1234";  // You can make this a random password using UUID or similar logic
        databaseHelper.updatePassword(username, tempPassword);
        return tempPassword;
    }
}
