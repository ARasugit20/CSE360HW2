package application;

import java.sql.SQLException;

import databasePart1.DatabaseHelper;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;



/**
 * AddRemoveUserRole allows to remove or add user roles and also delete users
 * This page displays a simple welcome message for the admin.
 */

public class AddRemoveUserRole {
	

    private final DatabaseHelper databaseHelper;
    // DatabaseHelper to handle database operations.
    public AddRemoveUserRole(DatabaseHelper databaseHelper) {
        this.databaseHelper = databaseHelper;
    }

	/**
     * Displays the features admin can do such as delete users
     * @param primaryStage The primary stage where the scene will be displayed.
     */
    public void show(Stage primaryStage, User user) {
    	VBox layout = new VBox();
    	
	    layout.setStyle("-fx-alignment: center; -fx-padding: 20;");
	    
	    // label to display the welcome message for the admin
	    Label adminLabel = new Label("Hello, Admin!");
	    adminLabel.setStyle("-fx-font-size: 16px; -fx-font-weight: bold;");
	    
	    //Label to produce errors
	    Label errorLabel = new Label();
        errorLabel.setStyle("-fx-text-fill: red; -fx-font-size: 12px;");
        
        //Button to logout
	    Button Logout = new Button("Logout");
	    Logout.setOnAction(a -> {
	    	new UserLoginPage(databaseHelper).show(primaryStage);
	    	
	    });
	    
	    //Delete User Button
	    Button deleteUserButton = new Button("Delete User");
	    deleteUserButton.setOnAction(a -> {
	    	TextField userNameField = new TextField();
	        userNameField.setPromptText("Enter userName");
	        userNameField.setMaxWidth(250);
	        
	        //Confirm button
	        Button comfirmButton = new Button("Comfirm addition");
			comfirmButton.setOnAction(b -> {
				String userName = userNameField.getText();
		        if (userName.isEmpty()) {
		            errorLabel.setText("Error: Username cannot be empty!");
		            return;
		        	}
		        boolean userExist = databaseHelper.doesUserExist(userName);
		        String userRole = databaseHelper.getUserRole(userName);
		        if (!userExist) {
		            errorLabel.setText("Error: User does not exist!");
		            return;
		        	}
		        if ("admin".equals(userRole)) {
		            errorLabel.setText("Error: Cannot delete an admin user!");
		            return;
		        	}
		        boolean success = databaseHelper.deleteUser(userName);
		        if (success) {
		            errorLabel.setText("Success, User removed!");
		        } else {
		            errorLabel.setText("Error, User removal unsuccessful!");
		        	}
				});
	        layout.getChildren().addAll(userNameField, comfirmButton);
	    });
	    
	    //Button to add user role
	    Button addUserRoleButton = new Button("Add User Role");
	    addUserRoleButton.setOnAction(a -> {
	    	TextField userNameField = new TextField();
	    	userNameField.setPromptText("Enter userName");
	        userNameField.setMaxWidth(250);
	        TextField roleNameField = new TextField();
	        roleNameField.setPromptText("Enter new role");
	        roleNameField.setMaxWidth(250);
	        
	        //Comfirm button
	        Button comfirmButton = new Button("Comfirm addition");
			comfirmButton.setOnAction(b -> {
				String newUserRole = roleNameField.getText();
		        String userName = userNameField.getText();
		        boolean userExist = databaseHelper.doesUserExist(userName);
		        if(userExist) {
			        	try {
			        	databaseHelper.addUserRole(userName, newUserRole);
			        	errorLabel.setText("Success, User role added!");
			        	
			        	} catch (SQLException e) {
			                System.err.println("Database error: " + e.getMessage());
			                e.printStackTrace();
			                errorLabel.setText("Error, User role addition unsuccessful!");
			            }
		        }
			});
		    
	        layout.getChildren().addAll(userNameField, roleNameField, comfirmButton);
        });
	    
	  //Button to remove user role
	    Button removeUserRoleButton = new Button("Remove User Role");
	    removeUserRoleButton.setOnAction(a -> {
	    	TextField userNameField = new TextField();
	    	userNameField.setPromptText("Enter userName");
	        userNameField.setMaxWidth(250);
	        
	        TextField roleNameField = new TextField();
	        roleNameField.setPromptText("Enter role to remove");
	        roleNameField.setMaxWidth(250);
	        
	        //comfirm button
	        Button comfirmButton = new Button("Comfirm");
			comfirmButton.setOnAction(b -> {
		        String userName = userNameField.getText();
		        String userRole = databaseHelper.getUserRole(userName);
		        boolean userExist = databaseHelper.doesUserExist(userName);
		     
		        if(userExist) {
			        if(!userRole.equals("admin") && userRole != null) {
			        	try {
			        	databaseHelper.removeUserRole(userName, userRole);
			        	errorLabel.setText("Success, User role removed!");
			        	
			        	} catch (SQLException e) {
			                System.err.println("Database error: " + e.getMessage());
			                e.printStackTrace();
			                errorLabel.setText("Error, User role removal unsuccessful!");
			            	}
			        	}
		        }
			});
	        layout.getChildren().addAll(userNameField, roleNameField, comfirmButton);
        });
	    

	    layout.getChildren().addAll(adminLabel, deleteUserButton, removeUserRoleButton, addUserRoleButton, errorLabel, Logout);
	    Scene adminScene = new Scene(layout, 800, 400);

	    // Set the scene to primary stage
	    primaryStage.setScene(adminScene);
	    primaryStage.setTitle("Add or Remove User Role Page");
    }
}