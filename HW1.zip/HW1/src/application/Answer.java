package application;

import java.time.LocalDateTime;

public class Answer {
    private int id;
    private int questionId;
    private String answerText;
    private boolean isAccepted;
    private String answeredByUser; 
    private LocalDateTime timestamp;

    public Answer(int id, int questionId, String answerText, String answeredByUser) {
        if (answerText == null || answerText.trim().isEmpty()) {
            throw new IllegalArgumentException("Answer text cannot be empty.");
        }

        this.id = id;
        this.questionId = questionId;
        this.answerText = answerText;
        this.answeredByUser = answeredByUser;
        this.isAccepted = false;
        this.timestamp = LocalDateTime.now();
    }

    // Getters
    public int getId() { return id; }
    public int getQuestionId() { return questionId; }
    public String getAnswerText() { return answerText; }
    public boolean isAccepted() { return isAccepted; }
    public String getAnsweredByUser() { return answeredByUser; }
    public LocalDateTime getTimestamp() { return timestamp; }

    // Setters
    public void setAnswerText(String answerText) { this.answerText = answerText; }
    public void setAnsweredByUser(String answeredByUser) { this.answeredByUser = answeredByUser; }

    // Mark the answer as accepted
    public void markAsAccepted() { this.isAccepted = true; }
}
