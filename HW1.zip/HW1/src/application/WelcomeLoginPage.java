package application;

import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;
import javafx.application.Platform;
import databasePart1.*;
import java.sql.SQLException;
import java.util.ArrayList;

/**
 * The WelcomeLoginPage class displays a welcome screen for authenticated users.
 * It allows users to navigate to their respective pages based on their role or quit the application.
 */
public class WelcomeLoginPage {
    
    private final DatabaseHelper databaseHelper;

    public WelcomeLoginPage(DatabaseHelper databaseHelper) {
        this.databaseHelper = databaseHelper;
    }

    public void show(Stage primaryStage, User user) {
        VBox layout = new VBox(10);
        layout.setStyle("-fx-alignment: center; -fx-padding: 20;");

        Label welcomeLabel = new Label("Welcome!!");
        welcomeLabel.setStyle("-fx-font-size: 16px; -fx-font-weight: bold;");
        layout.getChildren().add(welcomeLabel);

        // ✅ Get all roles assigned to the user
        ArrayList<String> userRoles = databaseHelper.getUserRoleList(user.getUserName());

        // ✅ If user has only one role, redirect immediately
        if (userRoles.size() == 1) {
            String role = userRoles.get(0);
            if ("admin".equals(role)) {
                new AdminHomePage(databaseHelper).show(primaryStage, user);
            } else {
                new UserHomePage(databaseHelper).show(primaryStage, user);
            }
            return;
        }

        // ✅ If user has multiple roles, provide navigation buttons

        // If user is admin, provide admin options
        if (userRoles.contains("admin")) {
            Button inviteButton = new Button("Invite Users");
            inviteButton.setOnAction(a -> new InvitationPage().show(databaseHelper, primaryStage));

            Button adminButton = new Button("Admin Page");
            adminButton.setOnAction(a -> new AdminHomePage(databaseHelper).show(primaryStage, user));

            layout.getChildren().addAll(inviteButton, adminButton);
        }

        // If user is a student
        if (userRoles.contains("student")) {
            Button studentButton = new Button("Student Page");
            studentButton.setOnAction(a -> new UserHomePage(databaseHelper).show(primaryStage, user));
            layout.getChildren().add(studentButton);
        }

        // If user is an instructor
        if (userRoles.contains("instructor")) {
            Button instructorButton = new Button("Instructor Page");
            instructorButton.setOnAction(a -> new UserHomePage(databaseHelper).show(primaryStage, user));
            layout.getChildren().add(instructorButton);
        }

        // If user is staff
        if (userRoles.contains("staff")) {
            Button staffButton = new Button("Staff Page");
            staffButton.setOnAction(a -> new UserHomePage(databaseHelper).show(primaryStage, user));
            layout.getChildren().add(staffButton);
        }

        // If user is a reviewer
        if (userRoles.contains("reviewer")) {
            Button reviewerButton = new Button("Reviewer Page");
            reviewerButton.setOnAction(a -> new UserHomePage(databaseHelper).show(primaryStage, user));
            layout.getChildren().add(reviewerButton);
        }

        // ✅ Button to go to Question-Answer Page
        Button qaButton = new Button("View Questions & Answers");
        qaButton.setOnAction(a -> {
            try {
                new QuestionAnswerPage(new QuestionsDatabaseHelper(), new AnswersDatabaseHelper()).show(primaryStage);
            } catch (SQLException e) {
                e.printStackTrace();
            }
        });
        layout.getChildren().add(qaButton);

        // ✅ Switch Roles Button (allows switching between multiple roles)
        if (userRoles.size() > 1) {
            Button switchRolesButton = new Button("Switch Roles");
            switchRolesButton.setOnAction(a -> showRoleSelection(primaryStage, user, userRoles));
            layout.getChildren().add(switchRolesButton);
        }

        // Quit Button
        Button quitButton = new Button("Quit");
        quitButton.setOnAction(a -> {
            databaseHelper.closeConnection();
            Platform.exit();
        });

        layout.getChildren().addAll(quitButton);
        Scene welcomeScene = new Scene(layout, 800, 400);
        primaryStage.setScene(welcomeScene);
        primaryStage.setTitle("Welcome Page");
    }

    /**
     * Displays a dialog for users with multiple roles to select which page to enter.
     */
    private void showRoleSelection(Stage primaryStage, User user, ArrayList<String> roles) {
        Stage dialog = new Stage();
        dialog.setTitle("Select Role");

        Label instructionLabel = new Label("You have multiple roles. Choose one:");

        // Dropdown menu for role selection
        ComboBox<String> roleSelection = new ComboBox<>();
        roleSelection.getItems().addAll(roles);
        roleSelection.setValue(roles.get(0)); // Default to first role

        // Button to confirm role selection
        Button continueButton = new Button("Continue");
        continueButton.setOnAction(e -> {
            String selectedRole = roleSelection.getValue();
            dialog.close();

            System.out.println("🔄 Switching to role: " + selectedRole);

            // Navigate based on selected role
            if ("admin".equals(selectedRole)) {
                new AdminHomePage(databaseHelper).show(primaryStage, user);
            } else {
                new UserHomePage(databaseHelper).show(primaryStage, user);
            }
        });

        VBox dialogLayout = new VBox(10);
        dialogLayout.setStyle("-fx-padding: 20; -fx-alignment: center;");
        dialogLayout.getChildren().addAll(instructionLabel, roleSelection, continueButton);

        dialog.setScene(new Scene(dialogLayout, 400, 200));
        dialog.show();
    }
}
