package application;

import java.sql.SQLException;

import databasePart1.*;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

/**
 * FirstPage class represents the initial screen for the first user.
 * It prompts the user to set up administrator access and navigate to the setup screen.
 */
public class FirstPage {
	
	// Reference to the DatabaseHelper for database interactions
	private final DatabaseHelper databaseHelper;
	public FirstPage(DatabaseHelper databaseHelper) {
        this.databaseHelper = databaseHelper;
    }

	/**
     * Displays the first page in the provided primary stage. 
     * @param primaryStage The primary stage where the scene will be displayed.
     */
	
    public void show(Stage primaryStage) {
    	VBox layout = new VBox(5);
    	
    	// Label to display the welcome message for the first user
	    layout.setStyle("-fx-alignment: center; -fx-padding: 20;");
	    Label userLabel = new Label("Hello..You are the first person here. \nPlease input account information to setup administrator access");
	    userLabel.setStyle("-fx-font-size: 16px; -fx-font-weight: bold;");
	    	
	    	//get username from user
	    	TextField userNameField = new TextField();
	        userNameField.setPromptText("Enter Admin userName");
	        userNameField.setMaxWidth(250);

	        //get password from user
	        PasswordField passwordField = new PasswordField();
	        passwordField.setPromptText("Enter Password");
	        passwordField.setMaxWidth(250);
	        
	        //Label to produce errors
	        Label errorLabel = new Label();
	        errorLabel.setStyle("-fx-text-fill: red; -fx-font-size: 12px;");

	        Button setupButton = new Button("Setup");
	        
	        setupButton.setOnAction(a -> {
	        	// Retrieve user input
	            String userName = userNameField.getText();
	            String password = passwordField.getText();
	            
	            System.out.println("userName is " + userName);
	            System.out.println("password is " + password);
	              
	            try {
	            	
	            	String userNameResult = UserNameRecognizer.checkForValidUserName(userName);
	            	String passwordResult = PasswordEvaluator.evaluatePassword(password);
	            	
	            	System.out.println("userName Result is " + userNameResult);
	            	System.out.println("password Password is " + passwordResult);
	            	
	            	// Check if the userName and password is valid
	            	if (userNameResult.isEmpty() && passwordResult.isEmpty()) {
	            	
	            		// Create a new User object with admin role and register in the database
	            		User user=new User(userName, password, "admin");
	            		databaseHelper.register(user);
	            		System.out.println("Administrator setup completed.");
	                
	            		// Navigate to the Welcome Login Page
	            		new UserLoginPage(databaseHelper).show(primaryStage); 
	                
	            	}	else {
	            		
	            			// Give reason for invalid userName
	            			if (!userNameResult.isEmpty()) {
	            				errorLabel.setText(userNameResult);
	            			}
	            			
	            			// Give reason for invalid password
	            			else if (!passwordResult.isEmpty()) {
	            			errorLabel.setText(passwordResult);
	            			}
	            		}
	            	}	catch (SQLException e) {
	                System.err.println("Database error: " + e.getMessage());
	                e.printStackTrace();
	            }
	            
	        });
	        

	    layout.getChildren().addAll(userLabel, userNameField, passwordField, setupButton, errorLabel); 
	    Scene firstPageScene = new Scene(layout, 800, 400);

	    // Set the scene to primary stage
	    primaryStage.setScene(firstPageScene);
	    primaryStage.setTitle("First Page");
    	primaryStage.show();
    }
}