package databasePart1;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class QuestionsDatabaseHelper {
    private static final String DB_URL = "jdbc:h2:~/FoundationDatabase";
    private static final String USER = "sa";
    private static final String PASS = "";

    private Connection connection;

    public QuestionsDatabaseHelper() throws SQLException {
        connection = DriverManager.getConnection(DB_URL, USER, PASS);
        createQuestionsTable();
    }

    private void createQuestionsTable() throws SQLException {
        String query = "CREATE TABLE IF NOT EXISTS Questions ("
                     + "id INT AUTO_INCREMENT PRIMARY KEY,"
                     + "title VARCHAR(255) NOT NULL,"
                     + "description TEXT NOT NULL,"
                     + "tags VARCHAR(255),"
                     + "askedByUser VARCHAR(255) NOT NULL,"
                     + "isResolved BOOLEAN DEFAULT FALSE,"
                     + "createdAt TIMESTAMP DEFAULT CURRENT_TIMESTAMP,"
                     + "updatedAt TIMESTAMP DEFAULT CURRENT_TIMESTAMP)";
        
        try (Statement stmt = connection.createStatement()) {
            stmt.execute(query);
        }
    }





    public void addQuestion(String title, String description, String tags, String askedByUser) throws SQLException {
        String query = "INSERT INTO Questions (title, description, tags, askedByUser) VALUES (?, ?, ?, ?)";
        try (PreparedStatement pstmt = connection.prepareStatement(query)) {
            pstmt.setString(1, title);
            pstmt.setString(2, description);
            pstmt.setString(3, tags);
            pstmt.setString(4, askedByUser);
            pstmt.executeUpdate();
        }
    }

    public void markQuestionAsResolved(int questionId) throws SQLException {
        String query = "UPDATE Questions SET isResolved = TRUE WHERE id = ?";
        try (PreparedStatement pstmt = connection.prepareStatement(query)) {
            pstmt.setInt(1, questionId);
            pstmt.executeUpdate();
        }
    }

    public List<String> getAllQuestions() throws SQLException {
        List<String> questions = new ArrayList<>();
        String query = "SELECT id, title FROM Questions ORDER BY id";
        
        try (Statement stmt = connection.createStatement();
             ResultSet rs = stmt.executeQuery(query)) {
            while (rs.next()) {
                questions.add(rs.getInt("id") + ": " + rs.getString("title"));
            }
        }
        return questions;
    }
    
    public boolean questionExists(int questionId) throws SQLException {
        String query = "SELECT COUNT(*) FROM Questions WHERE id = ?";
        try (PreparedStatement pstmt = connection.prepareStatement(query)) {
            pstmt.setInt(1, questionId);
            ResultSet rs = pstmt.executeQuery();
            return rs.next() && rs.getInt(1) > 0;
        }
    }

    public void updateQuestionTitle(int questionId, String newTitle) throws SQLException {
        String query = "UPDATE Questions SET title = ? WHERE id = ?";
        try (PreparedStatement pstmt = connection.prepareStatement(query)) {
            pstmt.setString(1, newTitle);
            pstmt.setInt(2, questionId);
            pstmt.executeUpdate();
        }
    }






    public void deleteQuestion(int questionId) throws SQLException {
        //  First, delete all answers related to this question
        String deleteAnswersQuery = "DELETE FROM Answers WHERE questionId = ?";
        try (PreparedStatement pstmt = connection.prepareStatement(deleteAnswersQuery)) {
            pstmt.setInt(1, questionId);
            pstmt.executeUpdate();
        }

        //  Then, delete the question itself
        String deleteQuestionQuery = "DELETE FROM Questions WHERE id = ?";
        try (PreparedStatement pstmt = connection.prepareStatement(deleteQuestionQuery)) {
            pstmt.setInt(1, questionId);
            pstmt.executeUpdate();
        }

        //  Reset auto-increment for Answers if no answers exist
        resetAutoIncrement("Answers");

        //  Reset auto-increment for Questions if no questions exist
        resetAutoIncrement("Questions");
    }
    private void resetAutoIncrement(String tableName) throws SQLException {
        String countQuery = "SELECT COUNT(*) FROM " + tableName;
        try (Statement stmt = connection.createStatement();
             ResultSet rs = stmt.executeQuery(countQuery)) {
            if (rs.next() && rs.getInt(1) == 0) { //  If table is empty
                try (Statement resetStmt = connection.createStatement()) {
                    resetStmt.execute("ALTER TABLE " + tableName + " ALTER COLUMN id RESTART WITH 1"); //  Reset ID to 1
                }
            }
        }
    }



    
}
