package databasePart1;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class AnswersDatabaseHelper {
    private static final String DB_URL = "jdbc:h2:~/FoundationDatabase";
    private static final String USER = "sa";
    private static final String PASS = "";

    private Connection connection;

    public AnswersDatabaseHelper() throws SQLException {
        connection = DriverManager.getConnection(DB_URL, USER, PASS);
        createAnswersTable();
    }

    private void createAnswersTable() throws SQLException {
        String query = "CREATE TABLE IF NOT EXISTS Answers ("
                     + "id INT AUTO_INCREMENT PRIMARY KEY,"
                     + "questionId INT NOT NULL,"
                     + "answerText TEXT NOT NULL,"
                     + "answeredByUser VARCHAR(255) NOT NULL,"
                     + "isAccepted BOOLEAN DEFAULT FALSE,"
                     + "createdAt TIMESTAMP DEFAULT CURRENT_TIMESTAMP,"
                     + "updatedAt TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,"
                     + "FOREIGN KEY (questionId) REFERENCES Questions(id) ON DELETE CASCADE)";
        try (Statement stmt = connection.createStatement()) {
            stmt.execute(query);
        }
    }


    public void addAnswer(int questionId, String answerText, String answeredByUser) throws SQLException {
        // Check if question exists
        String checkQuery = "SELECT COUNT(*) FROM Questions WHERE id = ?";
        try (PreparedStatement checkStmt = connection.prepareStatement(checkQuery)) {
            checkStmt.setInt(1, questionId);
            ResultSet rs = checkStmt.executeQuery();
            if (rs.next() && rs.getInt(1) == 0) {
                throw new SQLException("Error: Question ID " + questionId + " does not exist.");
            }
        }

        // Insert answer
        String query = "INSERT INTO Answers (questionId, answerText, answeredByUser) VALUES (?, ?, ?)";
        try (PreparedStatement pstmt = connection.prepareStatement(query)) {
            pstmt.setInt(1, questionId);
            pstmt.setString(2, answerText);
            pstmt.setString(3, answeredByUser);
            pstmt.executeUpdate();
        }
    }


    public void markAnswerAsAccepted(int answerId) throws SQLException {
        String query = "UPDATE Answers SET isAccepted = TRUE WHERE id = ?";
        try (PreparedStatement pstmt = connection.prepareStatement(query)) {
            pstmt.setInt(1, answerId);
            pstmt.executeUpdate();
        }
    }
   
    public boolean answerExists(int answerId) throws SQLException {
        String query = "SELECT COUNT(*) FROM Answers WHERE id = ?";
        try (PreparedStatement pstmt = connection.prepareStatement(query)) {
            pstmt.setInt(1, answerId);
            ResultSet rs = pstmt.executeQuery();
            return rs.next() && rs.getInt(1) > 0;
        }
    }

    public void updateAnswer(int answerId, String newText) throws SQLException {
        String query = "UPDATE Answers SET answerText = ? WHERE id = ?"; // Removed updatedAt
        try (PreparedStatement pstmt = connection.prepareStatement(query)) {
            pstmt.setString(1, newText);
            pstmt.setInt(2, answerId);
            
            int rowsAffected = pstmt.executeUpdate();
            if (rowsAffected == 0) {
                throw new SQLException("No rows updated. Answer ID might not exist.");
            }
        }
    }



    public void deleteAnswer(int answerId) throws SQLException {
        String query = "DELETE FROM Answers WHERE id = ?";
        try (PreparedStatement pstmt = connection.prepareStatement(query)) {
            pstmt.setInt(1, answerId);
            pstmt.executeUpdate();
        }

        //  Reset auto-increment for Answers if no answers exist
        resetAutoIncrement("Answers");
    }

    private void resetAutoIncrement(String tableName) throws SQLException {
        String countQuery = "SELECT COUNT(*) FROM " + tableName;
        try (Statement stmt = connection.createStatement();
             ResultSet rs = stmt.executeQuery(countQuery)) {
            if (rs.next() && rs.getInt(1) == 0) { //  If table is empty
                try (Statement resetStmt = connection.createStatement()) {
                    resetStmt.execute("ALTER TABLE " + tableName + " ALTER COLUMN id RESTART WITH 1"); //  Reset ID to 1
                }
            }
        }
    }


    public List<String> getAllAnswersForQuestion(int questionId) throws SQLException {
        List<String> answers = new ArrayList<>();
        String query = "SELECT id, answerText FROM Answers WHERE questionId = ? ORDER BY id"; //  Only fetch answers for given question

        try (PreparedStatement pstmt = connection.prepareStatement(query)) {
            pstmt.setInt(1, questionId);
            ResultSet rs = pstmt.executeQuery();
            
            int displayNumber = 1; //  Start numbering from 1
            while (rs.next()) {
                int answerId = rs.getInt("id"); //  Getting real answer ID
                String answerText = rs.getString("answerText");
                answers.add(answerId + ": " + answerText); // Show correct ID
                displayNumber++;
            }
        }
        return answers;
    }



    public List<String> getAllAnswers() throws SQLException {
        List<String> answers = new ArrayList<>();
        String query = "SELECT id, questionId, answerText FROM Answers ORDER BY id";

        try (Statement stmt = connection.createStatement();
             ResultSet rs = stmt.executeQuery(query)) {
            while (rs.next()) {
                int id = rs.getInt("id");
                int questionId = rs.getInt("questionId");
                String answerText = rs.getString("answerText");
                answers.add(id + " (Q" + questionId + "): " + answerText);
            }
        }
        return answers;
    }

}
