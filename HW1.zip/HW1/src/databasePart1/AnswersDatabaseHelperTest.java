package databasePart1;

import org.junit.jupiter.api.*;
import java.sql.SQLException;
import java.util.List;


import static org.junit.jupiter.api.Assertions.*;

@TestMethodOrder(MethodOrderer.OrderAnnotation.class)
public class AnswersDatabaseHelperTest {
    private static AnswersDatabaseHelper answersDB;
    private static int testQuestionId;

    @BeforeAll
    static void setup() throws SQLException {
        answersDB = new AnswersDatabaseHelper();
        QuestionsDatabaseHelper questionsDB = new QuestionsDatabaseHelper();
        questionsDB.addQuestion("Test Question for Answers", "Description", "tag", "user");
        List<String> questions = questionsDB.getAllQuestions();
        testQuestionId = Integer.parseInt(questions.get(0).split(": ")[0]); // Extract first question's ID
    }

    @Test
    @Order(1)
    void testAddAnswer() throws SQLException {
        answersDB.addAnswer(testQuestionId, "JUnit Test Answer", "testUser");
        List<String> answers = answersDB.getAllAnswersForQuestion(testQuestionId);
        assertTrue(answers.stream().anyMatch(a -> a.contains("JUnit Test Answer")));
    }

    @Test
    @Order(2)
    void testGetAllAnswers() throws SQLException {
        List<String> answers = answersDB.getAllAnswersForQuestion(testQuestionId);
        assertNotNull(answers);
        assertFalse(answers.isEmpty());
    }

    @Test
    @Order(3)
    void testUpdateAnswer() throws SQLException {
        List<String> answers = answersDB.getAllAnswersForQuestion(testQuestionId);
        assertFalse(answers.isEmpty());

        int answerId = Integer.parseInt(answers.get(0).split(": ")[0]); // Extract first answer's ID
        answersDB.updateAnswer(answerId, "Updated Answer Text");

        List<String> updatedAnswers = answersDB.getAllAnswersForQuestion(testQuestionId);
        assertTrue(updatedAnswers.stream().anyMatch(a -> a.contains("Updated Answer Text")));
    }

    @Test
    @Order(4)
    void testDeleteAnswer() throws SQLException {
        List<String> answers = answersDB.getAllAnswersForQuestion(testQuestionId);
        assertFalse(answers.isEmpty());

        int answerId = Integer.parseInt(answers.get(0).split(": ")[0]); // Extract first answer's ID
        answersDB.deleteAnswer(answerId);

        List<String> updatedAnswers = answersDB.getAllAnswersForQuestion(testQuestionId);
        assertFalse(updatedAnswers.stream().anyMatch(a -> a.contains(String.valueOf(answerId))));
    }
}
