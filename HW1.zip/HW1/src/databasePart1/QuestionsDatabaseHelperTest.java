package databasePart1;

import org.junit.jupiter.api.*;
import java.sql.SQLException;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

@TestMethodOrder(MethodOrderer.OrderAnnotation.class) // Ensures ordered execution
public class QuestionsDatabaseHelperTest {
    private static QuestionsDatabaseHelper questionsDB;

    @BeforeAll
    static void setup() throws SQLException {
        questionsDB = new QuestionsDatabaseHelper();
    }

    @Test
    @Order(1)
    void testAddQuestion() throws SQLException {
        questionsDB.addQuestion("JUnit Test Question", "Test Description", "testTag", "testUser");
        List<String> questions = questionsDB.getAllQuestions();
        assertTrue(questions.stream().anyMatch(q -> q.contains("JUnit Test Question")));
    }

    @Test
    @Order(2)
    void testGetAllQuestions() throws SQLException {
        List<String> questions = questionsDB.getAllQuestions();
        assertNotNull(questions);
        assertFalse(questions.isEmpty());
    }

    @Test
    @Order(3)
    void testUpdateQuestionTitle() throws SQLException {
        List<String> questions = questionsDB.getAllQuestions();
        assertFalse(questions.isEmpty());

        int questionId = Integer.parseInt(questions.get(0).split(": ")[0]); // Extract first question's ID
        questionsDB.updateQuestionTitle(questionId, "Updated Title");

        List<String> updatedQuestions = questionsDB.getAllQuestions();
        assertTrue(updatedQuestions.stream().anyMatch(q -> q.contains("Updated Title")));
    }

    @Test
    @Order(4)
    void testDeleteQuestion() throws SQLException {
        List<String> questions = questionsDB.getAllQuestions();
        assertFalse(questions.isEmpty());

        int questionId = Integer.parseInt(questions.get(0).split(": ")[0]); // Extract first question's ID
        questionsDB.deleteQuestion(questionId);

        List<String> updatedQuestions = questionsDB.getAllQuestions();
        assertFalse(updatedQuestions.stream().anyMatch(q -> q.contains(String.valueOf(questionId))));
    }
}
